package com.example.mathsirs.models

data class TeacherDetails(
    val teachers: List<Teacher>
)