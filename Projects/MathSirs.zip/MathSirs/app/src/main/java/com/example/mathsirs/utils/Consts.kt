package com.example.mathsirs.utils

const val BASE_URL = "https://api.jsonbin.io"
const val ENDPOINT = "/v3/b/681e13378a456b79669a6e4c?meta=false"